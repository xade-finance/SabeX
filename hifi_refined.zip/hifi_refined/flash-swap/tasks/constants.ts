export const TASK_DEPLOY_CONTRACT_FLASH_UNISWAP_V2: string = "deploy:contract:flash-uniswap-v2";
export const SUBTASK_DEPLOY_WAIT_FOR_CONFIRMATIONS: string = "deploy:wait-for-confirmations";
