export const SUBTASK_DEPLOY_WAIT_FOR_CONFIRMATIONS: string = "deploy:wait-for-confirmations";
export const TASK_DEPLOY_CONTRACT_HIFI_PROXY_TARGET: string = "deploy:contract:hifi-proxy-target";
