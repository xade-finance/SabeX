export const SUBTASK_DEPLOY_WAIT_FOR_CONFIRMATIONS: string = "deploy:wait-for-confirmations";
export const TASK_DEPLOY_CONTRACT_HIFI_POOL: string = "deploy:contract:hifi-pool";
export const TASK_DEPLOY_CONTRACT_HIFI_POOL_REGISTRY: string = "deploy:contract:hifi-pool-registry";
export const TASK_INIT_ADD_LIQUIDITY: string = "init:add-liquidity";
