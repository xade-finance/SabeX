const rootSolCover = require("../../.solcover");

module.exports = {
  ...rootSolCover,
  skipFiles: ["test"],
};
